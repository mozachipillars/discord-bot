"""Log for Trivia cog."""

import logging

__all__ = ["LOG"]

LOG = logging.getLogger("red.trivia")
