.. include:: _includes/_create-env-with-venv-intro.rst

.. prompt:: bash

    python3.11 -m venv ~/redenv

.. include:: _includes/_create-env-with-venv-outro.rst
