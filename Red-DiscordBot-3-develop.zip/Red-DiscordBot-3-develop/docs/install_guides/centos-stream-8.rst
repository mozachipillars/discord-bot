.. _install-centos-stream-8:

=================================
Installing Red on CentOS Stream 8
=================================

.. include:: _includes/install-guide-rhel8-derivatives.rst
